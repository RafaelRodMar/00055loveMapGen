# 00055loveMapGen
Map generator made with Löve.

The libraries class.lua, graph.lua, table_heap.lua and heap.lua belong to https://github.com/TheAlgorithms/Lua

delaunay.lua belongs to https://github.com/Yonaba/delaunay

voronoi.lua belongs to https://github.com/TomK32/iVoronoi
